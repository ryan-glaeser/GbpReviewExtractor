Step 1: Unzip
Step 2: Right click Run.command -> Open
Step 3: Enter the year and month in the requested format