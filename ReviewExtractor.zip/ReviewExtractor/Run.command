#!/bin/bash
cd "$(dirname "$0")"
xattr -d com.apple.quarantine ./ReviewExtractor 2>/dev/null
codesign --force --sign - ./ReviewExtractor 2>/dev/null
chmod +x ./ReviewExtractor
./ReviewExtractor
echo; read -p "Done. Press Enter to close."